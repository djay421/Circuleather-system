<?php
require __DIR__ . '/core/auth.php';
vereisLogin();
require __DIR__ . '/components/functies.php';

$criteria = haalCriteria($pdo);
$steden = haalSteden($pdo);
$bigbags = haalBigbags($pdo);

$errors = [];
// Of dit formulier vanuit de scanpagina is geopend (add.php?code=...):
// alleen dan gaan we na het opslaan terug naar de scanpagina.
$vanuitScan = trim((string)($_GET['code'] ?? '')) !== '';

$input = [
    'code' => trim((string)($_GET['code'] ?? '')),
    'categorie' => $_GET['categorie'] ?? 'leersample',
        'locatie' => '',
        'status' => 'beschikbaar',
        'stad_id' => '',
        'binnenkomst_datum' => '',
        'bigbag_id' => trim((string)($_GET['bigbag_id'] ?? '')),
    ];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($input as $key => $default) {
        $input[$key] = trim($_POST[$key] ?? $default);
    }

    if (!in_array($input['categorie'], CATEGORIEEN, true)) {
        $errors[] = 'Ongeldige categorie.';
    }

    // Een code is verplicht en uniek voor bigbags (de QR); een leersample
    // heeft geen QR, een eigen partij-nummer is alleen optioneel.
    if ($input['categorie'] === 'bigbag') {
        if ($input['code'] === '') {
            $errors[] = 'QR-code / partij-nummer is verplicht voor een bigbag.';
        } elseif (mb_strlen($input['code']) > 50) {
            $errors[] = 'Code mag maximaal 50 tekens bevatten.';
        } else {
            $stmt = $pdo->prepare('SELECT id FROM voorraad WHERE code = ?');
            $stmt->execute([$input['code']]);
            if ($stmt->fetch()) {
                $errors[] = 'Deze code bestaat al.';
            }
        }
        $input['bigbag_id'] = ''; // een bigbag hoort niet bij een andere bigbag
    } elseif ($input['code'] !== '') {
        if (mb_strlen($input['code']) > 50) {
            $errors[] = 'Code mag maximaal 50 tekens bevatten.';
        } else {
            $stmt = $pdo->prepare('SELECT id FROM voorraad WHERE code = ?');
            $stmt->execute([$input['code']]);
            if ($stmt->fetch()) {
                $errors[] = 'Deze code bestaat al.';
            }
        }
    }

    if (!in_array($input['status'], STATUSSEX, true)) {
        $errors[] = 'Ongeldige status.';
    }
    if ($input['binnenkomst_datum'] !== '') {
        $d = DateTime::createFromFormat('Y-m-d', $input['binnenkomst_datum']);
        if (!$d || $d->format('Y-m-d') !== $input['binnenkomst_datum']) {
            $errors[] = 'Ongeldige binnenkomst-datum.';
        }
    }
    if ($input['stad_id'] !== '') {
        $input['stad_id'] = (string)(int)$input['stad_id'];
        if ((int)$input['stad_id'] > 0 && !isset($steden[(int)$input['stad_id']])) {
            $errors[] = 'Ongeldige herkomststad.';
        }
    } else {
        $input['stad_id'] = '';
    }
    if ($input['bigbag_id'] !== '') {
        $input['bigbag_id'] = (string)(int)$input['bigbag_id'];
        if (!isset($bigbags[(int)$input['bigbag_id']])) {
            $errors[] = 'Ongeldige bigbag.';
        }
    } else {
        $input['bigbag_id'] = '';
    }

    // Criteria-waarden uit POST lezen en valideren.
    $categorie = in_array($input['categorie'], CATEGORIEEN, true) ? $input['categorie'] : 'leersample';
    $waarden = leesPostWaarden($criteria, $categorie, $_POST);
    $errors = array_merge($errors, valideerCriteriaWaarden($waarden, $criteria));

    $fotoPad = null;
    if (empty($errors) && $categorie === 'leersample' && !empty($_FILES['foto']['name'] ?? '')) {
        [$fotoPad, $fout] = verwerkFotoUpload($_FILES['foto'] ?? []);
        if ($fout) {
            $errors[] = $fout;
        }
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare(
            'INSERT INTO voorraad (code, categorie, stad_id, bigbag_id, locatie, status, binnenkomst_datum, foto)
             VALUES (:code, :categorie, :stad_id, :bigbag_id, :locatie, :status, :binnenkomst_datum, :foto)'
        );
        $stmt->execute([
            'code' => $input['code'] !== '' ? $input['code'] : null,
            'categorie' => $categorie,
            'stad_id' => $input['stad_id'] !== '' ? (int)$input['stad_id'] : null,
            'bigbag_id' => $categorie === 'leersample' && $input['bigbag_id'] !== ''
                ? (int)$input['bigbag_id']
                : null,
            'locatie' => $input['locatie'],
            'status' => $input['status'],
            'binnenkomst_datum' => $input['binnenkomst_datum'] !== '' ? $input['binnenkomst_datum'] : null,
            'foto' => $fotoPad,
        ]);
        $nieuwId = (int)$pdo->lastInsertId();
        bewaarCriteriaWaarden($pdo, $nieuwId, $waarden);
        logActie($pdo, 'toegevoegd', ($categorie === 'bigbag' ? 'Bigbag ' : 'Leersample ')
            . ($input['code'] !== '' ? $input['code'] : ('#' . $nieuwId)) . ' toegevoegd');

        // Terug naar waar je vandaan kwam:
        //  * handmatig toevoegen (via de voorraadpagina) -> terug naar de voorraadlijst;
        //  * registreren ná een scan (add.php?code=...) -> terug naar de scanpagina,
        //    zodat je direct bevestigd ziet dat de gescande code nu geregistreerd is.
        // Scannen is dus nooit verplicht: de code van een bigbag kun je ook gewoon
        // intypen bij het toevoegen.
        if ($categorie === 'bigbag' && $vanuitScan && $input['code'] !== '') {
            $doel = 'scan.php?code=' . rawurlencode($input['code']);
        } else {
            $doel = 'index.php?soort=' . $categorie . '&msg=added';
        }
        header('Location: ' . $doel);
        exit;
    }
}

$categorie = in_array($input['categorie'], CATEGORIEEN, true) ? $input['categorie'] : 'leersample';
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <?php $titel = 'Circuleather — Voorraad toevoegen'; ?>
    <?php include __DIR__ . '/components/head.php'; ?>
</head>
<body>
    <?php include __DIR__ . '/components/nav.php'; ?>
    <a class="back-link" href="index.php">Terug naar overzicht</a>
    <h1>Nieuwe voorraad toevoegen</h1>

    <?php if (!empty($errors)): ?>
        <div class="errors">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <label for="categorie">Categorie</label>
        <div class="radio-row">
            <label><input type="radio" name="categorie" value="bigbag" <?= $categorie === 'bigbag' ? 'checked' : '' ?> onchange="toonCategorie()"> Bigbag (heeft QR-code)</label>
            <label><input type="radio" name="categorie" value="leersample" <?= $categorie === 'leersample' ? 'checked' : '' ?> onchange="toonCategorie()"> Leersample (handmatig geregistreerd)</label>
        </div>

        <label for="code">Code <span id="code-vereist-label">(QR / partij-nummer van de bigbag) *</span></label>
        <input type="text" id="code" name="code" value="<?= htmlspecialchars($input['code']) ?>" autofocus
               placeholder="<?= $categorie === 'bigbag' ? 'Bijv. BB-2026-001' : 'Optioneel eigen nummer — samples hebben geen QR' ?>">

        <label for="locatie">Locatie</label>
        <input type="text" id="locatie" name="locatie" value="<?= htmlspecialchars($input['locatie']) ?>">

        <label for="status">Status</label>
        <select id="status" name="status">
            <?php foreach (STATUSSEX as $status): ?>
                <option value="<?= $status ?>" <?= $input['status'] === $status ? 'selected' : '' ?>><?= ucfirst(str_replace('_', ' ', $status)) ?></option>
            <?php endforeach; ?>
        </select>

        <fieldset id="velden-bigbag">
            <legend>Bigbag</legend>
            <p class="meta">Een bigbag heeft een unieke QR/streepjescode en wordt bij binnenkomst
            geregistreerd: herkomststad, datum, gewicht en inhoud.</p>
            <label for="stad_id">Herkomststad</label>
            <select id="stad_id" name="stad_id">
                <option value="">— kies —</option>
                <?php foreach ($steden as $id => $naam): ?>
                    <option value="<?= $id ?>" <?= (string)$id === $input['stad_id'] ? 'selected' : '' ?>><?= htmlspecialchars($naam) ?></option>
                <?php endforeach; ?>
            </select>

            <label for="binnenkomst_datum">Binnenkomst datum</label>
            <input type="date" id="binnenkomst_datum" name="binnenkomst_datum" value="<?= htmlspecialchars($input['binnenkomst_datum']) ?>">

            <?php toonCriteriaVelden($criteria, 'bigbag'); ?>
        </fieldset>

        <fieldset id="velden-leersample">
            <legend>Leersample</legend>
            <p class="meta">Leersamples worden handmatig geregistreerd met de selectiecriteria.
            Koppel ze aan de bigbag waar ze uit komen, zodat de herkomst bekend blijft.</p>

            <label for="foto">Foto (optioneel)</label>
            <input type="file" id="foto" name="foto" accept="image/*">
            <p class="meta">Maak direct een foto met je telefooncamera of kies een bestaande
            afbeelding (jpg/png/webp, max 10&nbsp;MB). De foto verschijnt in de galerij.</p>

            <label for="bigbag_id">Afkomstig uit bigbag (optioneel)</label>
            <select id="bigbag_id" name="bigbag_id">
                <option value="">— geen / losse sample —</option>
                <?php foreach ($bigbags as $bid => $label): ?>
                    <option value="<?= $bid ?>" <?= $input['bigbag_id'] !== '' && (int)$input['bigbag_id'] === $bid ? 'selected' : '' ?>><?= htmlspecialchars($label) ?></option>
                <?php endforeach; ?>
            </select>

            <?php toonCriteriaVelden($criteria, 'leersample'); ?>
        </fieldset>

        <div class="form-acties">
            <a href="index.php">Annuleren</a>
            <button type="submit">Toevoegen</button>
        </div>
    </form>

    <script>
        function toonCategorie() {
            var waarde = document.querySelector('input[name="categorie"]:checked').value;
            document.getElementById('velden-bigbag').style.display = waarde === 'bigbag' ? '' : 'none';
            document.getElementById('velden-leersample').style.display = waarde === 'leersample' ? '' : 'none';
            var codeVeld = document.getElementById('code');
            var label = document.getElementById('code-vereist-label');
            if (waarde === 'bigbag') {
                codeVeld.required = true;
                codeVeld.placeholder = 'Bijv. BB-2026-001';
                label.textContent = '(QR / partij-nummer van de bigbag) *';
            } else {
                codeVeld.required = false;
                codeVeld.placeholder = 'Optioneel eigen nummer — samples hebben geen QR';
                label.textContent = '(optioneel eigen nummer)';
            }
        }
        toonCategorie();
    </script>
</body>
</html>
