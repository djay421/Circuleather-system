<?php
return [
    'host' => 'sql301.infinityfree.com',
    'dbname' => 'if0_42826696_circuleather',
    'user' => 'if0_42826696',
    'password' => 'Agility08',
];